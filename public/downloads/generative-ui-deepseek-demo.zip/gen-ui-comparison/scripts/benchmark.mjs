import {run} from '../lib/run.mjs';
import {scenarios} from '../lib/scenarios.mjs';
import {writeFile} from 'node:fs/promises';
const schemes=['openui','a2ui','json-render'],rounds=Number(process.env.ROUNDS||3),batch=new Date().toISOString().replace(/[:.]/g,'-'),records=[];
for(let round=0;round<rounds;round++)for(const [i,scenario]of Object.keys(scenarios).entries())for(let j=0;j<3;j++){
 const scheme=schemes[(round+i+j)%3];const r=await run(scheme,scenario,'',()=>{},{batch,round:round+1});records.push(r);
 console.log(JSON.stringify({n:records.length,id:r.id,round:round+1,scheme,scenario,valid:r.valid,tokens:r.usage?.total_tokens,ms:Math.round(r.totalMs),error:r.error||r.validationError}));
 await writeFile(`results/batch-${batch}.json`,JSON.stringify({batch,rounds,records:records.map(r=>r.id)},null,2));
}
