import http from 'node:http';
import {createServer as createVite} from 'vite';
import {readFile,readdir} from 'node:fs/promises';
import {run} from './lib/run.mjs';
import {scenarios} from './lib/scenarios.mjs';
const vite=await createVite({server:{middlewareMode:true},appType:'spa'});let busy=false;
const server=http.createServer(async(req,res)=>{
 const url=new URL(req.url,'http://localhost');
 const json=(code,obj)=>{res.writeHead(code,{'Content-Type':'application/json','Cache-Control':'no-store'});res.end(JSON.stringify(obj));};
 try{
 if(url.pathname==='/api/scenarios')return json(200,scenarios);
 if(url.pathname==='/api/latest'){const files=(await readdir('results')).filter(x=>/^[a-f0-9-]{36}\.json$/.test(x));const rows=await Promise.all(files.map(f=>readFile('results/'+f,'utf8').then(JSON.parse)));const row=rows.filter(r=>r.scheme===url.searchParams.get('scheme')&&r.scenario===url.searchParams.get('scenario')).sort((a,b)=>b.startedAt.localeCompare(a.startedAt))[0];return json(row?200:404,row||{error:'尚无对应实测记录'});}
 if(url.pathname==='/api/results')return json(200,(await readdir('results')).filter(x=>/^[a-f0-9-]{36}\.json$/.test(x)));
 if(url.pathname.startsWith('/api/result/')){const id=url.pathname.split('/').pop();if(!/^[a-f0-9-]{36}$/.test(id))return json(400,{error:'Invalid id'});return json(200,JSON.parse(await readFile(`results/${id}.json`,'utf8')));}
 if(url.pathname==='/api/generate'&&req.method==='POST'){
  if(req.headers.origin && !['http://127.0.0.1:4175','http://localhost:4175'].includes(req.headers.origin))return json(403,{error:'Origin denied'});
  if(busy)return json(429,{error:'已有生成任务，请稍后重试'});
  let body='';for await(const c of req){body+=c;if(body.length>8000)return json(413,{error:'Input too large'});}
  const {scheme,scenario,custom=''}=JSON.parse(body);if(typeof custom!=='string'||custom.length>2000)return json(400,{error:'Invalid prompt'});
  busy=true;res.writeHead(200,{'Content-Type':'text/event-stream','Cache-Control':'no-cache','X-Accel-Buffering':'no'});const send=(type,data)=>res.write(`data: ${JSON.stringify({type,data})}\n\n`);
  try{const r=await run(scheme,scenario,custom,d=>send('delta',d));send('result',r);}catch(e){send('error',e.message);}finally{busy=false;res.end();}return;
 }
 vite.middlewares(req,res,()=>{res.statusCode=404;res.end();});
 }catch(e){json(500,{error:e.code==='ENOENT'?'Result not found':e.message});}
});server.listen(4175,'127.0.0.1',()=>console.log('Demo http://127.0.0.1:4175'));
