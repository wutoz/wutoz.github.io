# DeepSeek 生成式 UI 对比实验

三条路线共用真实 DeepSeek 流式 API，使用四组固定业务输入。HTML 路线自行生成 HTML/CSS/JS，**不是 OpenUI 官方应用的端到端测评**；A2UI 使用官方 MessageProcessor 与 React A2uiSurface；json-render 使用官方 Catalog/Registry/Renderer。两套声明式渲染器共用七种业务组件，包含 SVG 图表和本地表单校验。

## 运行

Node.js 24、npm，以及可访问 DeepSeek 的网络环境。

```bash
npm ci
cp .env.example .env
# 编辑 .env，填入自己的 DeepSeek API Key
node --env-file=.env server.mjs
```

打开 http://127.0.0.1:4175 。「调用 DeepSeek」发起真实计费请求；「回放实测」读取已保存数据，不调用模型。所有 API 请求在服务端执行。`.env` 不应提交到版本库。

也可通过环境变量 `DEEPSEEK_CREDENTIAL_FILE` 指向已有 YAML 凭据文件，其中需有 `DEEPSEEK_API_KEY: ...` 键；服务端直接读取，不复制凭据。需要环境代理时使用 Node 24 的 `NODE_USE_ENV_PROXY=1`。本地服务只监听 127.0.0.1，不是公网部署方案。

## 评测与复现

```bash
npm test
npm run build
node --env-file=.env scripts/benchmark.mjs
node scripts/summarize.mjs
node scripts/browser-check.mjs
```

浏览器测试默认使用已安装的 Google Chrome；可用 `CHROME_PATH` 指定可执行文件。共四场景 × 三路线 × 三轮，串行执行，每轮轮换路线顺序；不自动重试，不删除失败记录。服务需同时运行，浏览器验证读取最新 batch。

统一参数：`deepseek-flash`、`temperature=0`、`thinking=disabled`、`max_tokens=6000`、流式输出。A2UI 与 json-render 使用 DeepSeek `response_format=json_object`；HTML 使用文本输出。输入 Token 包含完整系统提示词和组件 Schema，未启用计费 Token 估算或固定模板回退。

所有流片段实时显示为源码；界面在完整输出通过校验后渲染。本实验不测渐进式 UI 首屏时间，也没有实现 A2UI 动态数据绑定、增量消息会话或 json-render SpecStream。此范围限制不代表官方框架缺少这些能力。

`results/` 保存正式36次运行的原始提示词、输出、usage、模型、请求ID和耗时，另有汇总与浏览器检查。`pilot-results/` 保留初测和冒烟记录，**不计入正式统计**。初测36次中两次 JSON 表单多出闭合字符；最终配置开启 JSON 模式后重新执行全量36次。初测资源校验曾误拒绝 SVG namespace URI；修正规则后的重新校验保留 initialValidation。没有修改模型原始输出。

- `firstContentMs`：发起请求至收到第一个非空 content delta。
- `totalMs`：发起请求至收到 SSE `[DONE]`，包含网络、服务端等待、生成和流读取，不含浏览器渲染。
- `usage`：API 返回的实际 Token 统计；缓存命中单列，未控制冷缓存。
- `valid`：HTML 完整文档与有限资源检查，或官方协议/目录及额外图结构校验。不同输出格式的校验强度不同，不能视为统一质量分。
- `browser-check.json`：页面内容、图表存在、表单反馈/重置及390px移动宽度检查；不覆盖生产鉴权、多轮状态或所有视觉细节。

HTML 在独立来源 iframe 中执行，只允许脚本及表单事件；CSP 禁止外部网络、表单网络提交、外部资源和 base。此策略用于本地演示，不是完整恶意代码审计。声明式方案的按钮仅能调用宿主允许的本地 submit/reset，不执行身份认证或业务请求。

## 目录

- `lib/`：真实 API 客户端、统一业务输入、提示词、协议校验、记录保存。
- `src/`：交互页面与官方渲染器适配。
- `scripts/`：批量评测、统计及浏览器检查。
- `tests/`：流解析、失败处理及协议/图结构验证。
- `screenshots/`：正式第一轮新闻与行情输出的六张截图。

正式组件目录为 `https://blog.wuto.site/catalogs/benchmark-v1`（本地目录标识，不要求在线获取）。A2UI 消息版本 v0.9；SDK版本与协议版本分别记录。全部测试数据为人工固定样例，不代表实时新闻、行情或生产业务。
