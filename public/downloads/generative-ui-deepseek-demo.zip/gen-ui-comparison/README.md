# DeepSeek 生成式 UI 对比实验

OpenUI 指 **Thesys 维护的 [thesysdev/openui](https://github.com/thesysdev/openui)**，是生成式 UI 的开放标准与框架。这里使用 OpenUI Lang 和官方 React Renderer，不是 W&B 的同名 HTML 生成项目。

三条路线共用真实 DeepSeek 流式 API 和四组固定业务输入。OpenUI 使用 `@openuidev/lang-core` / `@openuidev/react-lang 0.3.0`；A2UI 使用官方 MessageProcessor 与 A2uiSurface；json-render 使用官方 Catalog/Registry/Renderer。三者共享七种业务组件，包括 SVG 图表和本地表单校验。
## 运行

Node.js 24、npm，以及可访问 DeepSeek 的网络环境。

```bash
npm ci
cp .env.example .env
# 编辑 .env，填入自己的 DeepSeek API Key
node --env-file=.env server.mjs
```

打开 http://127.0.0.1:4175 。「调用 DeepSeek」发起真实计费请求；「回放实测」读取已保存数据，不调用模型。所有 API 请求在服务端执行。`.env` 不应提交到版本库。

也可通过环境变量 `DEEPSEEK_CREDENTIAL_FILE` 指向已有 YAML 凭据文件，其中需有 `DEEPSEEK_API_KEY: ...` 键；服务端直接读取，不复制凭据。需要环境代理时使用 Node 24 的 `NODE_USE_ENV_PROXY=1`。本地服务只监听 127.0.0.1，不是公网部署方案。

## 评测与复现

```bash
npm test
npm run build
node --env-file=.env scripts/benchmark.mjs
node scripts/summarize.mjs
node scripts/browser-check.mjs
```

浏览器测试默认使用已安装的 Google Chrome；可用 `CHROME_PATH` 指定可执行文件。共四场景 × 三路线 × 三轮，串行执行，每轮轮换路线顺序；不自动重试，不删除失败记录。服务需同时运行，浏览器验证读取最新 batch。

统一参数：`deepseek-flash`、`temperature=0`、`thinking=disabled`、`max_tokens=6000`、流式输出。A2UI 与 json-render 使用 DeepSeek `response_format=json_object`；OpenUI Lang 使用文本输出。输入 Token 包含完整系统提示词和组件 Schema，未启用计费 Token 估算或固定模板回退。

所有流片段实时显示为源码；界面在完整输出通过校验后渲染。本实验不测渐进式 UI 首屏时间，也没有评测 OpenUI 渐进式渲染、工具调用，或 A2UI 动态数据绑定、增量消息会话或 json-render SpecStream。此范围限制不代表官方框架缺少这些能力。

`results/` 保存纠正比较对象后重新执行的正式36次调用；`pilot-results/` 保存4次 OpenUI 冒烟测试，不计入统计。旧 HTML 路线的数据不在本包内，也不纳入结论。原始响应不作人工修改。
- `firstContentMs`：发起请求至收到第一个非空 content delta。
- `totalMs`：发起请求至收到 SSE `[DONE]`，包含网络、服务端等待、生成和流读取，不含浏览器渲染。
- `usage`：API 返回的实际 Token 统计；缓存命中单列，未控制冷缓存。
- `valid`：官方 OpenUI 解析器、A2UI 协议或 json-render 目录及额外结构检查。不同输出格式的校验强度不同，不能视为统一质量分。
- `browser-check.json`：页面内容、图表存在、表单反馈/重置及390px移动宽度检查；不覆盖生产鉴权、多轮状态或所有视觉细节。

三条路线只渲染已注册组件，不执行模型生成的 HTML 或 JavaScript。按钮仅能调用宿主允许的本地 submit/reset，不执行身份认证或业务请求。OpenUI 不使用 Cloud、Gateway 或 Autofix，而是直接调用 DeepSeek；系统提示词由官方 library.prompt() 从相同业务组件属性生成。A2UI 与 json-render 提示词包含各自格式说明及相同属性的 JSON Schema。完整提示词与输入 Token 均保留，不能将结果归因于输出语法这一个因素。

## 目录

- `lib/`：真实 API 客户端、统一业务输入、提示词、协议校验、记录保存。
- `src/`：交互页面与官方渲染器适配。
- `scripts/`：批量评测、统计及浏览器检查。
- `tests/`：流解析、失败处理及协议/图结构验证。
- `screenshots/`：正式第一轮新闻与行情输出的六张截图。

正式组件目录为 `https://blog.wuto.site/catalogs/benchmark-v1`（本地目录标识，不要求在线获取）。A2UI 消息版本 v0.9；SDK版本与协议版本分别记录。全部测试数据为人工固定样例，不代表实时新闻、行情或生产业务。
